package com.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONObject;

/**
 * Servlet implementation class WordCloudServlet
 */
@WebServlet("/WordCloudServlet")
public class WordCloudServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public WordCloudServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setHeader("Access-Control-Allow-Origin","*");
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setHeader("Access-Control-Allow-Origin","*");
		String method = request.getParameter("method");
		if(method.equals("wordCloud")) {
			JSONObject json = new JSONObject();
			List<JSONObject> jsons = new ArrayList<>();
			JSONObject json1 = new JSONObject();
			json1.put("name","������");
			json1.put("value",1200);
			jsons.add(json1);
			
			JSONObject json2 = new JSONObject();
			json2.put("name","��");
			json2.put("value",1200);
			jsons.add(json2);
			
			json.put("data", jsons);
			response.setCharacterEncoding("utf-8");
			response.getWriter().write(json.toJSONString());
		}
	}

}
