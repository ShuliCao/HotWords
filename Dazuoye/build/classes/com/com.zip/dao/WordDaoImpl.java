package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.model.Word;
import com.util.DBUtil;

public class WordDaoImpl implements IWordDao{

	@Override
	public Word search(String name) {
		// TODO Auto-generated method stub
		Connection connection = DBUtil.getConnection();
		String sql = "select * from words where name = ?";
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Word word = null;
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, name);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next()) {
				word = new Word();
				word.setAll(name, resultSet.getString("expl"));
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			DBUtil.close(resultSet);
			DBUtil.close(preparedStatement);
			DBUtil.close(connection);
		}
		return word;
	}
	
}
