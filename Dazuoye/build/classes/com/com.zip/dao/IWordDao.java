package com.dao;

import com.model.Word;

public interface IWordDao {
	public Word search(String name);
}
