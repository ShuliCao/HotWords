package com.model;

public class Word {
	String name;
	String expl;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getExpl() {
		return expl;
	}
	public void setExpl(String expl) {
		this.expl = expl;
	}
	public void setAll(String name,String expl) {
		this.name = name;
		this.expl = expl;
	}
}
